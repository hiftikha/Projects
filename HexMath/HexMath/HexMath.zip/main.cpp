//
//  main.cpp
//  HexMath
//
//  Created by Haroon Iftikhar on 4/2/17.
//  Copyright © 2017 Haroon Iftikhar. All rights reserved.
/*  This program takes in input in hexadecimal and performs addition, subtraction, division, multiplication, pow on them returning the ouput in dec form
*/

#include <iostream>
#include <cmath>

using namespace std;

void Divide(int64_t operand1, int64_t operand2){
    
    cout << operand1 << "/" << operand2 << " = " << "quotient " << operand1/operand2 << ", remainder " << operand1%operand2 << endl;
}
void Multiply(int64_t operand1, int64_t operand2){
    
    cout << operand1 << "*" << operand2 << " = " << operand1*operand2 << endl;
}
void Add(int64_t operand1, int64_t operand2){
    
    cout << operand1 << "+" << operand2 << " = " << operand1+operand2 << endl;
}
void Subtract(int64_t operand1, int64_t operand2){
    
    cout << operand1 << "-" << operand2 << " = " << operand1-operand2 << endl;
}
void Power(int64_t operand1, int64_t operand2){
    
    cout << operand1 << "$" << operand2 << " = " << pow(operand1, operand2) << endl;
}



int main() {
    // insert code here...
    int64_t op1;
    int64_t op2;
    char perform;
  
    do {
    cin >> hex >> op1 >> perform >> hex >> op2;
    
    if (perform == '/') {
        Divide(op1, op2);
    }
    else if(perform == '*'){
        Multiply(op1, op2);
    }
    else if (perform == '+'){
        Add(op1,op2);
    }
    else if (perform == '-'){
        Subtract(op1,op2);
    }
    else if (perform == '$'){
        Power(op1,op2);
    }
    } while (true);
    
    return 0;
}
