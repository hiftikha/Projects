//  Created by Haroon Iftikhar on 8/9/17.
//  Copyright © 2017 Haroon Iftikhar. All rights reserved.
//
Xcode Version 9.1 (9B55)


DESCRIPTION
This app is an AR based Magic Trick game that places a hat on the
first horizontal plane that the camera detects after the app is run.
It places an omni light at the coordinates of your phone
that were when that horizontal place was detected. It then allows
you to throw purple balls in the direction your phone's rear camera is facing, over and over again.
As many balls as you like!! Balls inside the hat can be vanished and brought back to
visibility by the press of a button. Magic! Enjoy!

HOW TO PLAY
Simple launch the app and scan the environment for a horizontal plane. Once detected,
a hat will be placed on the plane. You can now throw balls by pressing the Throw ball! button.
Once the balls are inside the hat, you can perform a magic trick and vanish them by hitting the Magic Trick! button.

