//
//  FavoriteCell.swift
//  PharmacyApp
//
//  Created by Haroon Iftikhar on 2/17/18.
//  Copyright © 2018 Haroon Iftikhar. All rights reserved.
//

import UIKit

class FavoriteCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
